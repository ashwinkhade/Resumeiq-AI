"""
AI & Data Science Career Tracker — Flask Application Factory.

Run with:
    flask --app run.py run --debug
or:
    python run.py
"""
import os
from flask import Flask
from app.extensions import db, migrate, jwt, bcrypt, limiter
from app.config import config_by_name
from app.utils.responses import error_response


def create_app(config_name=None):
    if config_name is None:
        config_name = os.environ.get("FLASK_ENV", "development")

    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_by_name[config_name])

    os.makedirs(app.instance_path, exist_ok=True)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    # --- Init extensions ---
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    bcrypt.init_app(app)
    limiter.init_app(app)

    from flask_cors import CORS
    CORS(
        app,
        resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}},
        supports_credentials=True,
    )

    # --- Register blueprints ---
    from app.routes.auth_routes import auth_bp
    app.register_blueprint(auth_bp, url_prefix="/api/auth")

    # Additional module blueprints are registered here as they are built:
    # profile_bp, score_bp, skill_bp, roadmap_bp, job_bp, project_bp,
    # certification_bp, prediction_bp, github_bp, resume_bp, admin_bp

    # --- JWT error handlers (consistent JSON shape) ---
    @jwt.unauthorized_loader
    def unauthorized_callback(reason):
        return error_response(f"Authentication required: {reason}", 401)

    @jwt.invalid_token_loader
    def invalid_token_callback(reason):
        return error_response(f"Invalid token: {reason}", 422)

    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return error_response("Token has expired. Please log in again.", 401)

    @jwt.revoked_token_loader
    def revoked_token_callback(jwt_header, jwt_payload):
        return error_response("Token has been revoked.", 401)

    # --- Generic error handlers ---
    @app.errorhandler(404)
    def not_found(e):
        return error_response("Resource not found.", 404)

    @app.errorhandler(405)
    def method_not_allowed(e):
        return error_response("Method not allowed.", 405)

    @app.errorhandler(413)
    def file_too_large(e):
        return error_response("Uploaded file is too large (max 5 MB).", 413)

    @app.errorhandler(500)
    def internal_error(e):
        db.session.rollback()
        return error_response("An internal server error occurred.", 500)

    @app.route("/api/health", methods=["GET"])
    def health_check():
        return {"status": "ok", "service": "career-tracker-api"}, 200

    return app
